package com.example.Kaloudis_PetBagHotelCap;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;


import com.google.android.material.button.MaterialButton;

public class HomeScreen extends AppCompatActivity {

    MaterialButton spaceAvail, checkIn;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home_screen);

        spaceAvail = findViewById(R.id.spaceAvail);
        checkIn = findViewById(R.id.checkIn);


        spaceAvail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), InventoryListScreen.class);
                startActivity(intent);
            }
        });

        checkIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), PetCheckInScreen.class);
                startActivity(intent);
            }
        });
    }

}
