package com.example.Kaloudis_PetBagHotelCap;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.material.button.MaterialButton;

public class LogInActivity extends AppCompatActivity {

    EditText username, password;
    MaterialButton loginbutton4, registerButton3;
    DBHelper DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log_in);

        username = (EditText) findViewById(R.id.username3);
        password = (EditText) findViewById(R.id.password4);
        loginbutton4 = (MaterialButton) findViewById(R.id.loginButton4);
        registerButton3 = (MaterialButton) findViewById(R.id.registerButton3);
        DB = new DBHelper(this);

        loginbutton4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String user = username.getText().toString();
                String pass = password.getText().toString();

                if (user.equals("") || pass.equals("")) {
                    Toast.makeText(LogInActivity.this,"Please enter all fields.", Toast.LENGTH_SHORT).show();
                }
                else{
                    Boolean checkUsernamePassword = DB.checkUsernamePassword(user, pass);
                    if (checkUsernamePassword == true){
                        Toast.makeText(LogInActivity.this,"Sign In Successful!", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(getApplicationContext(), HomeScreen.class);
                        startActivity(intent);
                    }
                    else {
                        Toast.makeText(LogInActivity.this,"Invalid Credentials.", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        registerButton3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), RegisterActivity.class);
                startActivity(intent);
            }
        });
    }
}