package com.example.Kaloudis_PetBagHotelCap;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.material.button.MaterialButton;

public class UpdateInventory extends AppCompatActivity {

    EditText itemName3, itemQuantity5, itemQuantity6;
    MaterialButton updateButton4, deleteButton4;
    String ID;
    String itemName;
    String itemQuantity;
    String itemQuantity2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_inventory);

        itemName3 = findViewById(R.id.itemName3);
        itemQuantity5 = findViewById(R.id.itemQuantity5);
        itemQuantity6 = findViewById(R.id.itemQuantity6);
        updateButton4 = findViewById(R.id.updateButton4);
        deleteButton4 = findViewById(R.id.deleteButton4);
        getAndSetIntentData();

        ActionBar ab = getSupportActionBar();
        if (ab != null){
            ab.setTitle(itemName);
        }

        updateButton4.setOnClickListener(v -> {
            DBHelperAdd myDB = new DBHelperAdd(UpdateInventory.this);
            itemName = itemName3.getText().toString().trim();
            itemQuantity = itemQuantity5.getText().toString().trim();
            itemQuantity2 = itemQuantity6.getText().toString().trim();
            myDB.updateDataTableSpace(ID, itemName, itemQuantity, itemQuantity2);
        });

        deleteButton4.setOnClickListener(v -> {
            confirmDialogue();
        });

    }

    void getAndSetIntentData(){
        if (getIntent().hasExtra("itemID") && getIntent().hasExtra("petType")
                && getIntent().hasExtra("freeSpace") && getIntent().hasExtra("totalSpace")){
            ID = getIntent().getStringExtra("itemID");
            itemName = getIntent().getStringExtra("petType");
            itemQuantity = getIntent().getStringExtra("freeSpace");
            itemQuantity2 = getIntent().getStringExtra("totalSpace");

            itemName3.setText(itemName);
            itemQuantity5.setText(itemQuantity);
            itemQuantity6.setText(itemQuantity2);

        }
        else {
            Toast.makeText(this, "No Data.", Toast.LENGTH_SHORT).show();
        }
    }

    void confirmDialogue(){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Delete " + itemName + " ?");
        builder.setMessage("Are you sure you want to delete " + itemName + " ?");
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                DBHelperAdd myDB = new DBHelperAdd(UpdateInventory.this);
                myDB.deleteOneRowAndRestartNumberingTableSpace(ID);
                finish();
            }
        });
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
            }
        });
        builder.create().show();
    }



}