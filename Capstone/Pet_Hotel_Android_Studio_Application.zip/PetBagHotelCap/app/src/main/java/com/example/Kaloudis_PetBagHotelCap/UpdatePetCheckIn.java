package com.example.Kaloudis_PetBagHotelCap;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.material.button.MaterialButton;


public class UpdatePetCheckIn extends AppCompatActivity{
    EditText petName2, petWeight2, ownerFirstName2, ownerLastName2, ownerEmail2, ownerPhoneNumber2, checkInDate2, checkOutDate2;
    MaterialButton updateButton5, deleteButton5;
    String ID3, petName, petWeight, ownerFirstName, ownerLastName, ownerEmail, ownerPhoneNumber, checkInDate, checkOutDate;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_pet_check_in);

        petName2 = findViewById(R.id.petName2);
        petWeight2 = findViewById(R.id.petWeight2);
        ownerFirstName2 = findViewById(R.id.ownerFirstName2);
        ownerLastName2 = findViewById(R.id.ownerLastName2);
        ownerEmail2 = findViewById(R.id.ownerEmail2);
        ownerPhoneNumber2 = findViewById(R.id.ownerPhoneNumber2);
        checkInDate2 = findViewById(R.id.checkInDate2);
        checkOutDate2 = findViewById(R.id.checkOutDate2);
        getAndSetIntentData();

        ActionBar ab = getSupportActionBar();
        if (ab != null) {
            ab.setTitle(petName);
        }

        updateButton5.setOnClickListener(v -> {
            DBHelperAdd myDB = new DBHelperAdd(UpdatePetCheckIn.this);
            petName = petName2.getText().toString().trim();
            petWeight = petWeight2.getText().toString().trim();
            ownerFirstName = ownerFirstName2.getText().toString().trim();
            ownerLastName = ownerLastName2.getText().toString().trim();
            ownerEmail = ownerEmail2.getText().toString().trim();
            ownerPhoneNumber = ownerPhoneNumber2.getText().toString().trim();
            checkInDate = checkInDate2.getText().toString().trim();
            checkOutDate = checkOutDate2.getText().toString().trim();
            myDB.updateDataTableCheckIn(ID3,petName,petWeight, ownerFirstName, ownerLastName, ownerEmail, ownerPhoneNumber, checkInDate, checkOutDate);
        });

        deleteButton5.setOnClickListener(v ->{
            confirmDialogue2();
        });
    }

    void getAndSetIntentData(){
        if (getIntent().hasExtra("petName") && getIntent().hasExtra("petWeight") && getIntent().hasExtra("ownerFirstName") &&
                getIntent().hasExtra("ownerLastName") && getIntent().hasExtra("ownerEmail") && getIntent().hasExtra("ownerPhoneNumber")
                && getIntent().hasExtra("checkInDate") && getIntent().hasExtra("checkOutDate")){

            ID3 = getIntent().getStringExtra("item_id");
            petName = getIntent().getStringExtra("petWeight");
            ownerFirstName = getIntent().getStringExtra("ownerFirstname");
            ownerLastName = getIntent().getStringExtra("ownerLastName");
            ownerEmail = getIntent().getStringExtra("ownerEmail");
            ownerPhoneNumber = getIntent().getStringExtra("ownerPhoneNumber");
            checkInDate = getIntent().getStringExtra("checkInDate");
            checkOutDate = getIntent().getStringExtra("checkOutDate");

            petName2.setText(petName);
            petWeight2.setText(petWeight);
            ownerFirstName2.setText(ownerFirstName);
            ownerLastName2.setText(ownerLastName);
            ownerEmail2.setText(ownerEmail);
            ownerPhoneNumber2.setText(ownerPhoneNumber);
            checkInDate2.setText(checkInDate);
            checkOutDate2.setText(checkOutDate);


        }

        else {
            Toast.makeText(this, "No Data", Toast.LENGTH_SHORT).show();
        }
    }


    void confirmDialogue2(){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Delete " + petName2 + " ?");
        builder.setMessage("Are you sure you want to delete " + petName2 + " ?");
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                DBHelperAdd myDB = new DBHelperAdd(UpdatePetCheckIn.this);
                myDB.deleteOneRowAndRestartNumberingTableCheckIn(ID3);
                finish();
            }
        });
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
            }
        });
        builder.create().show();
    }


}
