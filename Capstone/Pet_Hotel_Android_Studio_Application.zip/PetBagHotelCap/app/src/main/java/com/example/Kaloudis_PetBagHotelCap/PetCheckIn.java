package com.example.Kaloudis_PetBagHotelCap;

import androidx.appcompat.app.AppCompatActivity;


import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;


import com.google.android.material.button.MaterialButton;


public class PetCheckIn extends AppCompatActivity {
    EditText petName, petWeight, ownerFirstName, ownerLastName, ownerEmail, ownerPhoneNumber, checkInDate, checkOutDate;
    MaterialButton submitButton;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pet_check_in);

        petName = findViewById(R.id.petName);
        petWeight = findViewById(R.id.petWeight);
        ownerFirstName = findViewById(R.id.ownerFirstName);
        ownerLastName = findViewById(R.id.ownerLastName);
        ownerEmail = findViewById(R.id.ownerEmail);
        ownerPhoneNumber = findViewById(R.id.ownerPhoneNumber);
        checkInDate = findViewById(R.id.checkInDate);
        checkOutDate = findViewById(R.id.checkOutDate);
        submitButton = findViewById(R.id.submitButton);

        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DBHelperAdd myDB = new DBHelperAdd(PetCheckIn.this);
                myDB.addItemTablePetCheckIn(
                        petName.getText().toString(),
                        petWeight.getText().toString(),
                        ownerFirstName.getText().toString(),
                        ownerLastName.getText().toString(),
                        ownerEmail.getText().toString(),
                        ownerPhoneNumber.getText().toString(),
                        checkInDate.getText().toString(),
                        checkOutDate.getText().toString());

            }
        });
    }
}
