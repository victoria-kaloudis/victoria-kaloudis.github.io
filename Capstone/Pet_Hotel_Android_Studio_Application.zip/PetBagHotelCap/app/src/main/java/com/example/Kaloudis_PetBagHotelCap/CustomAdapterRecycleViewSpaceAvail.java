package com.example.Kaloudis_PetBagHotelCap;


import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class CustomAdapterRecycleViewSpaceAvail extends RecyclerView.Adapter<CustomAdapterRecycleViewSpaceAvail.MyViewHolder> {

    private Context context;
    Activity activity;

    private ArrayList itemID, itemName, itemQuantity, itemQuantity2;
    Animation translate_anim;


    CustomAdapterRecycleViewSpaceAvail(Activity activity, Context context, ArrayList itemID, ArrayList itemName, ArrayList itemQuantity, ArrayList itemQuantity2){
        this.activity = activity;
        this.context = context;
        this.itemID = itemID;
        this.itemName = itemName;
        this.itemQuantity = itemQuantity;
        this.itemQuantity2 = itemQuantity2;

    }

    @NonNull
    @Override
    public CustomAdapterRecycleViewSpaceAvail.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.first_row_space_avail, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, final int position) {
        holder.itemID.setText(String.valueOf(itemID.get(position)));
        holder.itemName.setText(String.valueOf(itemName.get(position)));
        holder.itemQuantity.setText(String.valueOf(itemQuantity.get(position)));
        holder.itemQuantity2.setText(String.valueOf(itemQuantity2.get(position)));
        holder.mainLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, UpdateInventory.class);
                intent.putExtra("itemID", String.valueOf(itemID.get(holder.getAdapterPosition())));
                intent.putExtra("petType", String.valueOf(itemName.get(holder.getAdapterPosition())));
                intent.putExtra("freeSpace", String.valueOf(itemQuantity.get(holder.getAdapterPosition())));
                intent.putExtra("totalSpace", String.valueOf(itemQuantity2.get(holder.getAdapterPosition())));
                activity.startActivityForResult(intent, 1);
            }
        });


    }


    @Override
    public int getItemCount() {
        return itemID.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder{

        TextView itemID, itemName, itemQuantity, itemQuantity2;
        RelativeLayout mainLayout;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            itemID = itemView.findViewById(R.id.itemID);
            itemName = itemView.findViewById(R.id.itemName2);
            itemQuantity = itemView.findViewById(R.id.itemQuantity2);
            itemQuantity2 = itemView.findViewById(R.id.itemQuantity3);
            mainLayout = itemView.findViewById(R.id.mainLayout);
            translate_anim = AnimationUtils.loadAnimation(context, R.anim.translate_anim);
            mainLayout.setAnimation(translate_anim);


        }
    }
}
