package com.example.Kaloudis_PetBagHotelCap;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

public class DBHelperAdd extends SQLiteOpenHelper {
    private Context context;
    private static final String DATABASE_NAME = "MyPetHotel.db";
    private static final int DATABASE_VERSION = 1;

    //Table Names
    private static final String TABLE_SPACE = "My_Pet_Space_Availability";
    private static final String TABLE_CHECK_IN = "Checked_In_Pets";


    //Common Column Names
    private static final String COLUMN_ID = "item_id";

    //Table Space - Column Names
    private static final String COLUMN_ITEM = "pet_type";
    private static final String COLUMN_QUANTITY_FREE = "free_spaces";
    private static final String COLUMN_QUANTITY_TOTAL = "total_spaces";

    //Table Check In - Column Names
    private static final String COLUMN_PET_NAME = "pet_name";
    private static final String COLUMN_PET_WEIGHT = "pet_weight";
    private static final String COLUMN_OWNER_FIRST_NAME = "owner_first_name";
    private static final String COLUMN_OWNER_LAST_NAME = "owner_last_name";
    private static final String COLUMN_OWNER_EMAIL = "owner_email";
    private static final String COLUMN_OWNER_PHONE_NUMBER = "owner_phone_number";
    private static final String COLUMN_CHECK_IN_DATE = "check_in_date";
    private static final String COLUMN_CHECK_OUT_DATE = "check_out_date";





    DBHelperAdd(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        String CREATE_TABLE_SPACE = "CREATE TABLE " + TABLE_SPACE +
                " (" + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_ITEM + " TEXT, " +
                COLUMN_QUANTITY_FREE + " INTEGER, " +
                COLUMN_QUANTITY_TOTAL + " INTEGER);";

        String CREATE_TABLE_CHECK_IN = "CREATE TABLE " + TABLE_CHECK_IN +
                " (" + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_PET_NAME + " TEXT, " +
                COLUMN_PET_WEIGHT + " INTEGER, " +
                COLUMN_OWNER_FIRST_NAME + " TEXT, " +
                COLUMN_OWNER_LAST_NAME + " TEXT, " +
                COLUMN_OWNER_EMAIL + " TEXT, " +
                COLUMN_OWNER_PHONE_NUMBER + "INTEGER, " +
                COLUMN_CHECK_IN_DATE + "TEXT, " +
                COLUMN_CHECK_OUT_DATE + "TEXT);";

        db.execSQL(CREATE_TABLE_SPACE);
        db.execSQL(CREATE_TABLE_CHECK_IN);


    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {

        db.execSQL("drop Table if exists TABLE_SPACE");
        db.execSQL("drop Table if exists TABLE_CHECK_IN");
        onCreate(db);
    }

    void addItemTableSpace(String petType, String freeSpace, String totalSpace){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put(COLUMN_ITEM,petType);
        cv.put(COLUMN_QUANTITY_FREE, freeSpace);
        cv.put(COLUMN_QUANTITY_TOTAL, totalSpace);
        long result = db.insert(TABLE_SPACE, null, cv);
        if (result == -1) {
            Toast.makeText(context, "Failed to add.", Toast.LENGTH_SHORT).show();
        }
        else {
            Toast.makeText(context, "Successfully Added!", Toast.LENGTH_SHORT).show();
        }
    }

    void addItemTablePetCheckIn(String petName, String petWeight, String ownerFirstName, String ownerLastName,
                                String ownerEmail, String ownerPhoneNumber, String checkInDate, String checkOutDate) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put(COLUMN_PET_NAME, petName);
        cv.put(COLUMN_PET_WEIGHT, petWeight);
        cv.put(COLUMN_OWNER_FIRST_NAME, ownerFirstName);
        cv.put(COLUMN_OWNER_LAST_NAME, ownerLastName);
        cv.put(COLUMN_OWNER_EMAIL, ownerEmail);
        cv.put(COLUMN_OWNER_PHONE_NUMBER, ownerPhoneNumber);
        cv.put(COLUMN_CHECK_IN_DATE, checkInDate);
        cv.put(COLUMN_CHECK_OUT_DATE, checkOutDate);
        long result = db.insert(TABLE_CHECK_IN, null, cv);
        if (result == -1) {
            Toast.makeText(context, "Failed to add.", Toast.LENGTH_SHORT).show();
        }
        else {
            Toast.makeText(context, "Successfully Added!", Toast.LENGTH_SHORT).show();
        }
    }



    Cursor readAllDataTableSpace(){

        String tableSpace = "SELECT * FROM " + DBHelperAdd.TABLE_SPACE;
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = null;
        if (db != null){
            cursor = db.rawQuery(tableSpace, null);

        }
        return cursor;
    }
    Cursor readAllDataTableCheckIn(){

        String tableCheckIn = "SELECT * FROM " + DBHelperAdd.TABLE_CHECK_IN;
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = null;
        if (db != null){
            cursor = db.rawQuery(tableCheckIn, null);

        }
        return cursor;
    }


    void updateDataTableSpace(String row_id, String petType, String freeSpace, String totalSpace){
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues cv = new ContentValues();

        cv.put(COLUMN_ITEM,petType);
        cv.put(COLUMN_QUANTITY_FREE, freeSpace);
        cv.put(COLUMN_QUANTITY_TOTAL, totalSpace);

        long result = db.update(TABLE_SPACE, cv, "item_id=?", new String[]{row_id});
        if (result == -1){
            Toast.makeText(context, "Failed to update.", Toast.LENGTH_SHORT).show();
        }
        else {
            Toast.makeText(context, "Successfully Updated!", Toast.LENGTH_SHORT).show();
        }
    }

    void updateDataTableCheckIn(String row_id, String petName, String petWeight, String ownerFirstName, String ownerLastName,
                                String ownerEmail, String ownerPhoneNumber, String checkInDate, String checkOutDate){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put(COLUMN_PET_NAME, petName);
        cv.put(COLUMN_PET_WEIGHT, petWeight);
        cv.put(COLUMN_OWNER_FIRST_NAME, ownerFirstName);
        cv.put(COLUMN_OWNER_LAST_NAME, ownerLastName);
        cv.put(COLUMN_OWNER_EMAIL, ownerEmail);
        cv.put(COLUMN_OWNER_PHONE_NUMBER, ownerPhoneNumber);
        cv.put(COLUMN_CHECK_IN_DATE, checkInDate);
        cv.put(COLUMN_CHECK_OUT_DATE, checkOutDate);

        long result = db.update(TABLE_CHECK_IN, cv, "item_id=?", new String[]{row_id});
        if (result == -1) {
            Toast.makeText(context, "Failed to add.", Toast.LENGTH_SHORT).show();
        }
        else {
            Toast.makeText(context, "Successfully Added!", Toast.LENGTH_SHORT).show();
        }
    }

    void deleteOneRowAndRestartNumberingTableSpace(String row_id) {
        SQLiteDatabase db = this.getWritableDatabase();
        long result = db.delete(TABLE_SPACE, "item_id=?", new String[]{row_id});
        if (result == -1) {
            Toast.makeText(context, "Failed to delete.", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(context, "Successfully Deleted!", Toast.LENGTH_SHORT).show();
        }
    }

    void deleteOneRowAndRestartNumberingTableCheckIn(String row_id){
        SQLiteDatabase db = this.getWritableDatabase();
        long result = db.delete(TABLE_CHECK_IN, "item_id=?", new String[]{row_id});
        if (result == -1) {
            Toast.makeText(context, "Failed to delete.", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(context, "Successfully Deleted!", Toast.LENGTH_SHORT).show();
        }
    }

    void deleteAllDataTableSpace(){
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("DELETE FROM " + TABLE_SPACE);
        db.execSQL("DELETE FROM sqlite_sequence WHERE name='My_Pet_Space_Availability'");

    }

    void deleteAllDataTablePetCheckIn(){
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("DELETE FROM " + TABLE_CHECK_IN);
        db.execSQL("DELETE FROM sqlite_sequence WHERE name='Checked_In_Pets'");

    }

}
