package com.example.Kaloudis_PetBagHotelCap;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.material.button.MaterialButton;

public class RegisterActivity extends AppCompatActivity {

    EditText firstname, lastname, username, password, repassword, phoneNumber;
    MaterialButton registerButton2, loginButton2;
    DBHelper DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        firstname = findViewById(R.id.firstname);
        lastname =  findViewById(R.id.lastname);
        username = findViewById(R.id.username2);
        password = findViewById(R.id.password2);
        repassword =  findViewById(R.id.password3);
        phoneNumber =  findViewById(R.id.phoneNumber);
        registerButton2 = findViewById(R.id.registerButton2);
        loginButton2 =  findViewById(R.id.loginButton2);
        DB = new DBHelper(this);



        registerButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String first = firstname.getText().toString();
                String last = lastname.getText().toString();
                String user = username.getText().toString();
                String pass = password.getText().toString();
                String repass = repassword.getText().toString();
                String phone = phoneNumber.getText().toString();


                if (first.equals("") || last.equals("") || user.equals("") || pass.equals("") || repass.equals("") || phone.equals("")) {
                    Toast.makeText(RegisterActivity.this,"Please enter all fields.", Toast.LENGTH_SHORT).show();
                }
                else {
                    if (pass.equals(repass)) {
                        Boolean checkUser = DB.checkUsername(user);
                        if (checkUser == false){
                            Boolean insert = DB.insertData(user, pass, phone);
                            if (insert == true) {
                                Toast.makeText(RegisterActivity.this,"Registered Successfully!", Toast.LENGTH_SHORT).show();
                                EmptyEditTextAfterDataInsert();
                                Intent intent = new Intent(getApplicationContext(), LogInActivity.class);
                                startActivity(intent);
                            }
                            else {
                                Toast.makeText(RegisterActivity.this,"Registration Failed.", Toast.LENGTH_SHORT).show();
                            }
                        }
                        else {
                            Toast.makeText(RegisterActivity.this,"User already exists. Please sign in.", Toast.LENGTH_SHORT).show();
                        }
                    }
                    else{
                        Toast.makeText(RegisterActivity.this,"Passwords are not matching.", Toast.LENGTH_SHORT).show();
                    }
                }


            }
        });

        loginButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), LogInActivity.class);
                startActivity(intent);
            }
        });


    }
    public void EmptyEditTextAfterDataInsert(){
        firstname.getText().clear();
        lastname.getText().clear();
        username.getText().clear();
        phoneNumber.getText().clear();
        password.getText().clear();
        repassword.getText().clear();
    }
}