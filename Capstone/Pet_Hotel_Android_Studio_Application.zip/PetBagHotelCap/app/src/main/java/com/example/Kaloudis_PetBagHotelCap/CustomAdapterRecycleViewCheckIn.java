package com.example.Kaloudis_PetBagHotelCap;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
public class CustomAdapterRecycleViewCheckIn extends RecyclerView.Adapter<CustomAdapterRecycleViewCheckIn.MyViewHolder2> {

    private Context context;
    Activity activity;

    private ArrayList itemID2, petName2, checkInDate2;
    Animation translate_anim2;

    CustomAdapterRecycleViewCheckIn(Activity activity, Context context, ArrayList itemID, ArrayList petName2, ArrayList checkInDate2){
        this.activity = activity;
        this.context = context;
        this.itemID2 = itemID;
        this.petName2 = petName2;
        this.checkInDate2 = checkInDate2;

    }


    @NonNull
    @Override
    public CustomAdapterRecycleViewCheckIn.MyViewHolder2 onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.first_row_pet_check_in, parent, false);
        return new MyViewHolder2(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder2 holder, final int position) {
        holder.itemID2.setText(String.valueOf(itemID2.get(position)));
        holder.petName2.setText(String.valueOf(petName2.get(position)));
        holder.checkInDate2.setText(String.valueOf(checkInDate2.get(position)));
        holder.mainLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, UpdatePetCheckIn.class);
                intent.putExtra("itemID", String.valueOf(itemID2.get(holder.getAdapterPosition())));
                intent.putExtra("petName", String.valueOf(petName2.get(holder.getAdapterPosition())));
                intent.putExtra("checkInDate", String.valueOf(checkInDate2.get(holder.getAdapterPosition())));
                activity.startActivityForResult(intent, 1);
            }
        });


    }

    @Override
    public int getItemCount() {return itemID2.size();}

    public class MyViewHolder2 extends RecyclerView.ViewHolder{

        TextView itemID2, petName2, checkInDate2;
        RelativeLayout mainLayout;
        public MyViewHolder2 (@NonNull View itemView) {
            super(itemView);
            itemID2 = itemView.findViewById(R.id.itemID);
            petName2 = itemView.findViewById(R.id.petName2);
            checkInDate2 = itemView.findViewById(R.id.checkInDate2);
            mainLayout = itemView.findViewById(R.id.mainLayout);
            translate_anim2 = AnimationUtils.loadAnimation(context, R.anim.translate_anim);
            mainLayout.setAnimation(translate_anim2);


        }
    }


}
