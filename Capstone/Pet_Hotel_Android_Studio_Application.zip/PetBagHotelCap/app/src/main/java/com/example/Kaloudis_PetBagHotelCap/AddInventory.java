package com.example.Kaloudis_PetBagHotelCap;


import androidx.appcompat.app.AppCompatActivity;


import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import com.google.android.material.button.MaterialButton;


public class AddInventory extends AppCompatActivity {

    EditText itemName, itemQuantity, itemQuantity2;
    MaterialButton addButton2;



    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_pet_type);

        itemName = findViewById(R.id.itemName);
        itemQuantity = findViewById(R.id.itemQuantity);
        itemQuantity2 = findViewById(R.id.itemQuantity4);
        addButton2 = findViewById(R.id.addButton2);

        addButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DBHelperAdd myDB = new DBHelperAdd(AddInventory.this);
                myDB.addItemTableSpace(itemName.getText().toString(), itemQuantity.getText().toString(),
                        itemQuantity2.getText().toString());

            }
        });

    }
}