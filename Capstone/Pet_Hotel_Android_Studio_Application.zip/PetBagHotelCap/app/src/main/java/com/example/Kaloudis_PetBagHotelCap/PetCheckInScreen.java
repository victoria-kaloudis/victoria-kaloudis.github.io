package com.example.Kaloudis_PetBagHotelCap;


import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import com.google.android.material.button.MaterialButton;

import java.util.ArrayList;

public class PetCheckInScreen extends AppCompatActivity {
    RecyclerView recyclerView2;
    MaterialButton addButton2, homeButton2;
    DBHelperAdd myDB;
    ArrayList<String> itemID2, petName2, checkInDate2;


    CustomAdapterRecycleViewCheckIn customAdapterRecycleView2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_check_in_pet_screen);

        recyclerView2 = findViewById(R.id.recyclerView2);
        addButton2 = findViewById(R.id.addButton2);
        homeButton2 = findViewById(R.id.homeButton2);

        addButton2.setOnClickListener(v -> {
            Intent intent = new Intent(PetCheckInScreen.this, PetCheckIn.class);
            startActivity(intent);
        });

        homeButton2.setOnClickListener(v -> {
            Intent intent = new Intent(PetCheckInScreen.this, HomeScreen.class);
            startActivity(intent);

        });


        myDB = new DBHelperAdd(PetCheckInScreen.this);
        itemID2 = new ArrayList<>();
        petName2 = new ArrayList<>();
        checkInDate2 = new ArrayList<>();

        storeDataInArrays2();
        customAdapterRecycleView2 = new CustomAdapterRecycleViewCheckIn(PetCheckInScreen.this, this, itemID2, petName2, checkInDate2);
        recyclerView2.setAdapter(customAdapterRecycleView2);
        recyclerView2.setLayoutManager(new LinearLayoutManager(PetCheckInScreen.this));

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == -1){
            recreate();
        }
    }

    void storeDataInArrays2(){
        Cursor cursor = myDB.readAllDataTableCheckIn();
        if (cursor.getCount()==0) {
            Toast.makeText(this, "No data.", Toast.LENGTH_SHORT).show();
        }
        else {
            while (cursor.moveToNext()){
                itemID2.add(cursor.getString(0));
                petName2.add(cursor.getString(1));
                checkInDate2.add(cursor.getString(2));
            }
        }
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.my_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.deleteAll){
            confirmDialogue();

        }
        return super.onOptionsItemSelected(item);
    }
    void confirmDialogue(){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Delete All?");
        builder.setMessage("Are you sure you want to delete all data?");
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                DBHelperAdd myDB = new DBHelperAdd(PetCheckInScreen.this);
                myDB.deleteAllDataTablePetCheckIn();
                Intent intent = new Intent(PetCheckInScreen.this, PetCheckIn.class);
                startActivity(intent);
                finish();
            }
        });
        builder.setNegativeButton("No", (dialog, which) -> {
        });
        builder.create().show();
    }


}
