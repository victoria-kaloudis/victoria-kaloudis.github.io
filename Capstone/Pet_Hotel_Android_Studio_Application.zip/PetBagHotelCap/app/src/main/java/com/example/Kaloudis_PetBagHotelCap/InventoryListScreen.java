package com.example.Kaloudis_PetBagHotelCap;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.google.android.material.button.MaterialButton;

import java.util.ArrayList;

public class InventoryListScreen extends AppCompatActivity {

    RecyclerView recyclerView;
    MaterialButton addButton, homeButton;
    DBHelperAdd myDB;
    ArrayList<String> itemID, itemName, itemQuantity, itemQuantity2;



    CustomAdapterRecycleViewSpaceAvail customAdapterRecycleView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory_list_screen);

        recyclerView = findViewById(R.id.recyclerView);
        addButton = findViewById(R.id.addButton);
        homeButton = findViewById(R.id.homeButton);

        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(InventoryListScreen.this, AddInventory.class);
                startActivity(intent);

            }
        });

        homeButton.setOnClickListener(new View.OnClickListener()  {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(InventoryListScreen.this, HomeScreen.class);
                startActivity(intent);

            }
        });



        myDB = new DBHelperAdd(InventoryListScreen.this);
        itemID = new ArrayList<>();
        itemName = new ArrayList<>();
        itemQuantity = new ArrayList<>();
        itemQuantity2 = new ArrayList<>();

        storeDataInArrays();
        customAdapterRecycleView = new CustomAdapterRecycleViewSpaceAvail(InventoryListScreen.this, this, itemID, itemName, itemQuantity, itemQuantity2);
        recyclerView.setAdapter(customAdapterRecycleView);
        recyclerView.setLayoutManager(new LinearLayoutManager(InventoryListScreen.this));

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == -1){
            recreate();
        }
    }

    void storeDataInArrays(){
        Cursor cursor = myDB.readAllDataTableSpace();
        if (cursor.getCount()==0) {
            Toast.makeText(this, "No data.", Toast.LENGTH_SHORT).show();
        }
        else {
            while (cursor.moveToNext()){
                itemID.add(cursor.getString(0));
                itemName.add(cursor.getString(1));
                itemQuantity.add(cursor.getString(2));
                itemQuantity2.add(cursor.getString(3));
            }
        }
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.my_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.deleteAll){
            confirmDialogue();

        }
        return super.onOptionsItemSelected(item);
    }

    void confirmDialogue(){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Delete All?");
        builder.setMessage("Are you sure you want to delete all data?");
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                DBHelperAdd myDB = new DBHelperAdd(InventoryListScreen.this);
                myDB.deleteAllDataTableSpace();
                Intent intent = new Intent(InventoryListScreen.this, InventoryListScreen.class);
                startActivity(intent);
                finish();
            }
        });
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
            }
        });
        builder.create().show();
    }


}